import pandas as pd
import os
import random
import matplotlib.pyplot as plt

materias_primas = [
    "Farinha de Trigo", "Açúcar", "Cacau em Pó", "Manteiga", "Fermento Químico",
    "Leite", "Ovos", "Gotas de Chocolate", "Essência de Baunilha", "Canela em Pó",
    "Amido de Milho", "Sal", "Mel", "Aveia", "Amendoim", "Nozes", "Castanha de Caju",
    "Chocolate em Barra", "Leite Condensado", "Creme de Leite"
]

produtos_acabados = [
    "Biscoito de Chocolate", "Biscoito de Baunilha", "Bolo de Chocolate", "Bolo de Cenoura",
    "Cookies com Gotas", "Biscoito de Canela", "Torta de Limão", "Pão de Mel", "Cupcake",
    "Brownie", "Mini Bolo", "Biscoito de Leite", "Bolo de Nozes", "Cookie Integral",
    "Pão de Queijo", "Empada", "Biscoito de Aveia", "Rosquinha Doce", "Bolo de Milho", "Muffin"
]

unidades = ["kg", "g", "L", "ml", "cx", "dz", "un"]

codigos = []
descricoes = []
categorias = []
unidades_lista = []
quantidades = []
valores_unitarios = []
valores_totais = []

for i in range(1, 401):
    if i % 5 != 0:
        codigo = f"MP{i:03}"
        descricao = random.choice(materias_primas)
        categoria = "Matéria-Prima"
    else:
        codigo = f"PA{i//5:03}"
        descricao = random.choice(produtos_acabados)
        categoria = "Produto Acabado"

    unidade = random.choice(unidades)
    quantidade = random.randint(1, 100)
    valor_unitario = round(random.uniform(1.0, 50.0), 2)
    valor_total = round(quantidade * valor_unitario, 2)

    codigos.append(codigo)
    descricoes.append(descricao)
    categorias.append(categoria)
    unidades_lista.append(unidade)
    quantidades.append(quantidade)
    valores_unitarios.append(valor_unitario)
    valores_totais.append(valor_total)

df = pd.DataFrame({
    "Código": codigos,
    "Descrição do Produto": descricoes,
    "Categoria": categorias,
    "Unidade": unidades_lista,
    "Quantidade": quantidades,
    "Valor Unitário (R$)": valores_unitarios,
    "Valor Total (R$)": valores_totais
})

arquivo = "planilha_produtos_400.xlsx"
df.to_excel(arquivo, index= False)
print(f"Planilha gerada com sucesso: {arquivo}")

def visualizar_planilha(lista_pilha):
    print("\n=== ITENS CADASTRADOS NA SESSÃO (do último para o primeiro) ===")
    
    if not lista_pilha:
        print("Nenhum item cadastrado nesta sessão.")
        return

    for i, item in enumerate(lista_pilha[::-1], start=1):
        print(f"{i} -> {item['Código']} | {item['Descrição do Produto']} | {item['Categoria']} | "
              f"{item['Unidade']} | {item['Valor Unitário (R$)']} | {item['Valor Total (R$)']}")

pilha = []
def menu():
    print("\n============ MENU ============")
    print("1 - Cadastrar novo produto")
    print("2 - Listar produtos (Cadastrados na Sessão)")
    print("3 - Listar todos os produtos (DataFrame)")
    print("4 - Excluir produto (Cadastrado na Sessão)")
    print("5 - Gráficos")
    print("6 - Sair (sem salvar)")
    print("7 - Salvar e Sair")
    print("==============================")
    return int(input("Escolha uma opção: "))


while True:
    try:
        cadastro = menu()
    except ValueError:
        print("Opção inválida. Digite um número.")
        continue

    if cadastro == 1:
        print ("CADASTRE UM NOVO PRODUTO")
        descricao = input("Nome do produto:")
        codigo = input("Código:")
        categoria = input("Categoria (Matéria - Prima ou Produto Acabado):")
        unidade = input("Unidade(kg, cx, L, dz...):")
        
        try:
            quantidade = float(input("Quantidade:"))
            valor_unitario = float(input("Valor unitário: ").replace(',', '.'))
        except ValueError:
            print("Erro: Quantidade e Valor Unitário devem ser números.")
            continue

        valor_total = round(quantidade * valor_unitario, 2) 

        novo_item = {
           "Descrição do Produto": descricao,
           "Código": codigo,
           "Categoria": categoria,
           "Unidade": unidade,
           "Quantidade": quantidade,
           "Valor Unitário (R$)": valor_unitario,
           "Valor Total (R$)": valor_total
        }

        pilha.append(novo_item)

        novo_item_df = pd.DataFrame([novo_item])
        df = pd.concat([df, novo_item_df], ignore_index=True)

        print(f"Produto '{descricao}' cadastrado com sucesso")

    elif cadastro == 2:
        visualizar_planilha(pilha)

    elif cadastro == 3:
        print("\n--- LISTA COMPLETA FINAL (DF) ---")
        df_invertido = df.iloc[::-1]
        print(df_invertido.to_string())
        
    elif cadastro == 4:
        visualizar_planilha(pilha)
        if not pilha:
            continue

        try:
            item_excluir = int(input("Digite o número do item que deseja excluir: "))
            if 1 <= item_excluir <= len(pilha):
                item_removido = pilha.pop(len(pilha) - item_excluir)
                df = df[df["Código"] != item_removido["Código"]] 
                print(f"Item '{item_removido['Descrição do Produto']}' excluído com sucesso.")
            else:
                print("Número inválido.")
        except ValueError:
            print("Entrada inválida. Por favor, digite um número.")

    elif cadastro == 5:
        print("\n--- Menu de Gráficos ---")
        print("1 - Comparar Preço x Quantidade (Gráfico de Dispersão)")
        print("2 - Voltar ao Menu Principal")
        
        try:
            sub_opcao = int(input("Escolha uma opção: "))
        except ValueError:
            print("Opção inválida.")
            continue

        if sub_opcao == 1:
            print("\n--- Selecione os Produtos para Comparar ---")
            
            nomes_unicos = sorted(df['Descrição do Produto'].unique())
            
            for i, nome in enumerate(nomes_unicos, 1):
                print(f"{i} - {nome}")
            
            print("\nDigite os NÚMEROS dos produtos que quer comparar, separados por vírgula (ex: 1, 5, 10)")
            selecao_str = input("Produtos: ")
            
            try:
                indices_selecionados = [int(x.strip()) - 1 for x in selecao_str.split(',')]
                
                nomes_selecionados = []
                for i in indices_selecionados:
                    if 0 <= i < len(nomes_unicos):
                        nomes_selecionados.append(nomes_unicos[i])
                    else:
                        print(f"Atenção: Número {i+1} é inválido e será ignorado.")
                
                if not nomes_selecionados:
                    print("Nenhum produto válido selecionado.")
                    continue

                df_para_plotar = df[df['Descrição do Produto'].isin(nomes_selecionados)]

                if df_para_plotar.empty:
                    print("Nenhum dado encontrado para os produtos selecionados.")
                    continue

                plt.figure(figsize=(10, 6))
                
                for nome in nomes_selecionados:
                    df_produto = df_para_plotar[df_para_plotar['Descrição do Produto'] == nome]
                    plt.scatter(
                        df_produto['Valor Unitário (R$)'], 
                        df_produto['Quantidade'], 
                        label=nome, 
                        alpha=0.7, 
                        s=50
                    )
                
                plt.title('Comparação: Preço Unitário vs. Quantidade em Estoque')
                plt.xlabel('Valor Unitário (R$)')
                plt.ylabel('Quantidade em Estoque')
                plt.legend()
                plt.grid(True)
                plt.tight_layout()
                plt.show()

            except ValueError:
                print("Erro: Digite apenas números separados por vírgula.")
            except Exception as e:
                print(f"Ocorreu um erro ao gerar o gráfico: {e}")

        elif sub_opcao == 2:
            continue
        else:
            print("Opção inválida.")
            
    elif cadastro == 6:
        print("Nenhum arquivo foi salvo.")
        print ("Saindo...")
        break
    
    elif cadastro == 7:
        formato = input("Deseja salvar os dados em Excel ou CSV? ").strip().lower()

        if formato == "excel":
            arquivo = "planilha_produtos_400.xlsx"
            df.to_excel(arquivo, index= False)
            print(f"Dados salvos com sucesso na planilha '{arquivo}'!")
            
        elif formato == "csv":
            arquivo = "planilha_produtos.csv"
            df.to_csv(arquivo, index= False, sep=";")
            print(f"Dados salvos com sucesso na planilha '{arquivo}'!")
            
        else:
            print("Opção inválida. Nenhum arquivo foi salvo.")

        print ("Saindo...")
        break
    
    else:
        print("Opção inválida. Tente novamente.")